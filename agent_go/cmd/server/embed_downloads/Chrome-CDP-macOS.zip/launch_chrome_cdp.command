#!/bin/bash
# Launch Chrome with remote debugging (CDP) enabled on port 9222

CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
USER_DATA_DIR="${HOME}/.chrome-cdp-profile"
PORT=9222

# Fallback to Chromium if Chrome not found
if [[ ! -x "$CHROME" ]]; then
    CHROME="/Applications/Chromium.app/Contents/MacOS/Chromium"
fi

if [[ ! -x "$CHROME" ]]; then
    echo ""
    echo "❌ ERROR: Google Chrome or Chromium not found in /Applications."
    echo "   Please install Google Chrome from https://www.google.com/chrome/"
    echo ""
    read -p "Press Enter to close..."
    exit 1
fi

echo "✅ Launching Chrome with CDP on port $PORT..."
echo "   Profile: $USER_DATA_DIR"
echo ""
echo "   Once Chrome opens, go back to the app and click 'Connect'."
echo ""

exec "$CHROME" \
    --remote-debugging-port="$PORT" \
    --user-data-dir="$USER_DATA_DIR" \
    --no-first-run \
    --no-default-browser-check \
    "$@"
